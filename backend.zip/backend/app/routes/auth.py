from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_session
from ..database.auth_models import Tenant, User
from ..security import hash_password, verify_password, create_access_token
from ..auth_deps import get_current_user


router = APIRouter(prefix="/auth", tags=["Auth"])


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    tenant_name: str = Field(min_length=1, max_length=255)
    tenant_slug: str = Field(min_length=2, max_length=64)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UpdateMeRequest(BaseModel):
    email: EmailStr | None = None
    current_password: str | None = None
    new_password: str | None = Field(default=None, min_length=8, max_length=128)


class UpdateTenantRequest(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)


@router.post("/register")
async def register(
    req: RegisterRequest,
    session: AsyncSession = Depends(get_session),
):
    email = req.email.lower()

    existing = await session.execute(select(User).where(User.email == email))
    if existing.scalar_one_or_none() is not None:
        raise HTTPException(status_code=400, detail="Email already registered")

    slug_check = await session.execute(select(Tenant).where(Tenant.slug == req.tenant_slug))
    if slug_check.scalar_one_or_none() is not None:
        raise HTTPException(status_code=400, detail="Tenant slug already taken")

    tenant = Tenant(name=req.tenant_name, slug=req.tenant_slug)
    session.add(tenant)
    await session.flush()

    user = User(
        tenant_id=tenant.id,
        email=email,
        password_hash=hash_password(req.password),
        role="admin",
    )
    session.add(user)
    await session.commit()
    await session.refresh(user)

    token = create_access_token(str(user.id), {"tenant_id": str(tenant.id), "role": user.role})

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": str(user.id), "email": user.email, "role": user.role},
        "tenant": {"id": str(tenant.id), "name": tenant.name, "slug": tenant.slug},
    }


@router.post("/login")
async def login(
    req: LoginRequest,
    session: AsyncSession = Depends(get_session),
):
    email = req.email.lower()
    result = await session.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()

    if user is None or not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token(
        str(user.id),
        {"tenant_id": str(user.tenant_id), "role": user.role},
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": str(user.id), "email": user.email, "role": user.role},
    }


@router.get("/me")
async def me(user: User = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    tenant = await session.get(Tenant, user.tenant_id)
    tenant_name = tenant.name if tenant else ""
    return {
        "id": str(user.id),
        "email": user.email,
        "role": user.role,
        "tenant_id": str(user.tenant_id),
        "tenant_name": tenant_name,
    }


@router.patch("/me")
async def update_me(
    req: UpdateMeRequest,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
):
    """Update the current user's email and/or password."""
    changed = False

    if req.email is not None and req.email.lower() != user.email:
        new_email = req.email.lower()
        existing = await session.execute(
            select(User).where(User.email == new_email, User.id != user.id)
        )
        if existing.scalar_one_or_none() is not None:
            raise HTTPException(status_code=400, detail="Email already in use")
        user.email = new_email
        changed = True

    if req.new_password is not None:
        if not req.current_password:
            raise HTTPException(status_code=400, detail="current_password required to change password")
        if not verify_password(req.current_password, user.password_hash):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
        user.password_hash = hash_password(req.new_password)
        changed = True

    if not changed:
        raise HTTPException(status_code=400, detail="No changes provided")

    await session.commit()
    await session.refresh(user)
    return {"id": str(user.id), "email": user.email, "role": user.role, "tenant_id": str(user.tenant_id)}


@router.patch("/tenant")
async def update_tenant(
    req: UpdateTenantRequest,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
):
    """Update the tenant's name (slug is immutable)."""
    if req.name is None:
        raise HTTPException(status_code=400, detail="No changes provided")
    tenant = await session.get(Tenant, user.tenant_id)
    if tenant is None:
        raise HTTPException(status_code=404, detail="Tenant not found")
    tenant.name = req.name
    await session.commit()
    await session.refresh(tenant)
    return {"id": str(tenant.id), "name": tenant.name, "slug": tenant.slug}
