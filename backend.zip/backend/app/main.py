from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

import sys as _sys
import asyncio as _asyncio
if _sys.platform == "win32":
    # Psycopg async mode requires SelectorEventLoop on Windows; the
    # ProactorEventLoop default breaks every async DB call, including
    # startup_recovery(). Set it before any app module is imported so
    # the async engine binds to the right loop.
    _asyncio.set_event_loop_policy(_asyncio.WindowsSelectorEventLoopPolicy())

from app.config import settings
from app.routes.orchestrator import router as orchestrator_router
from app.routes.auth import router as auth_router
from app.routes.approvals import router as approvals_router
from app.routes.audit import router as audit_router
from app.routes.integrations import router as integrations_router
from app.routes.documents import router as documents_router
from app.routes.analytics import router as analytics_router
from app.routes.team import router as team_router


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    debug=settings.DEBUG,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_recovery():
    """Mark stuck workflows on boot (Section 7.5)."""
    await _recover_stuck_workflows()



@app.get("/health", tags=["Health"])
async def health_check():
    return {
        "status": "healthy",
        "application": settings.PROJECT_NAME,
        "version": settings.VERSION,
    }


app.include_router(auth_router, prefix=settings.API_PREFIX)
app.include_router(orchestrator_router, prefix=settings.API_PREFIX)
app.include_router(approvals_router, prefix=settings.API_PREFIX)
app.include_router(audit_router, prefix=settings.API_PREFIX)
app.include_router(integrations_router, prefix=settings.API_PREFIX)
app.include_router(documents_router, prefix=settings.API_PREFIX)
app.include_router(analytics_router, prefix=settings.API_PREFIX)
app.include_router(team_router, prefix=settings.API_PREFIX)

# Serve the static command-center frontend at /app
STATIC_DIR = Path(__file__).resolve().parent / "static"
if STATIC_DIR.exists():
    app.mount("/app", StaticFiles(directory=str(STATIC_DIR), html=True), name="app-static")

from fastapi.responses import RedirectResponse
@app.get("/", include_in_schema=False)
async def _root_redirect():
    return RedirectResponse(url="/app/login.html")


async def _recover_stuck_workflows() -> None:
    """
    Recovery scan on boot (Section 7.5).

    `runs` is the actual workflow-execution table. Statuses in use:
      - 'failed'            -> possibly recoverable if state_json exists
      - 'completed'         -> nothing to do
      - 'pending_approval'  -> stale if old; alert only, don't change status

    We do NOT silently flip statuses; we log for visibility. Automatic
    resume of in-flight runs is a follow-up once the orchestrator persists
    a 'running' status row.
    """
    from datetime import datetime, timedelta, timezone
    from sqlalchemy import text
    from .database import SessionFactory
    from .tools.audit import log_event

    cutoff = datetime.now(timezone.utc) - timedelta(minutes=10)
    try:
        async with SessionFactory() as session:
            async with session.begin():
                failed_rows = (await session.execute(
                    text(
                        "SELECT id, tenant_id, status, state_json "
                        "FROM runs "
                        "WHERE status = 'failed' "
                        "AND state_json IS NOT NULL "
                        "AND created_at < :cutoff"
                    ),
                    {"cutoff": cutoff},
                )).mappings().all()

        for r in failed_rows:
            await log_event(
                tenant_id=str(r["tenant_id"]) if r["tenant_id"] else None,
                event_type="workflow.recoverable_on_boot",
                workflow_id=str(r["id"]),
                payload={
                    "previous_status": r["status"],
                    "had_state": r["state_json"] is not None,
                },
            )

        async with SessionFactory() as session:
            async with session.begin():
                stale_rows = (await session.execute(
                    text(
                        "SELECT id, tenant_id, status, created_at "
                        "FROM runs "
                        "WHERE status = 'pending_approval' "
                        "AND created_at < :cutoff"
                    ),
                    {"cutoff": cutoff},
                )).mappings().all()

        for r in stale_rows:
            await log_event(
                tenant_id=str(r["tenant_id"]) if r["tenant_id"] else None,
                event_type="workflow.stale_approval",
                workflow_id=str(r["id"]),
                payload={
                    "status": r["status"],
                    "created_at": r["created_at"].isoformat() if r["created_at"] else None,
                },
            )

        if failed_rows or stale_rows:
            print(f"[recovery] recoverable={len(failed_rows)} stale_approvals={len(stale_rows)}")
    except Exception:
        import traceback
        traceback.print_exc()

