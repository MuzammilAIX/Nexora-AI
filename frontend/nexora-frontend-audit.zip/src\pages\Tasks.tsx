import { useState, useEffect, useMemo } from 'react'
import {
  CheckCircle2, XCircle, Clock, Loader2, Search, RefreshCw,
  AlertCircle, Bot, List, LayoutGrid, Calendar, ExternalLink, X, ChevronRight, SkipForward
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'

interface Task {
  task_id: string
  raw_task_id: string
  run_id: string
  run_request: string
  run_status: string
  created_at: string
  agent_type: string
  description: string
  dependencies: string[]
  requires_approval: boolean
  approval_reason: string | null
  status: string
  approval_id: string | null
  reason: string | null
  result: any
}

const AGENT_COLORS: Record<string, string> = {
  support: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
  lead: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
  operations: 'bg-orange-500/10 text-orange-400 border-orange-500/30',
  reporting: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
  analytics: 'bg-green-500/10 text-green-400 border-green-500/30',
  email: 'bg-pink-500/10 text-pink-400 border-pink-500/30',
  research: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
  review: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
}

const STATUS_ORDER = ['queued', 'running', 'pending_approval', 'done', 'skipped', 'failed']
const STATUS_LABELS: Record<string, string> = {
  queued: 'Queued',
  running: 'Running',
  in_progress: 'Running',
  pending_approval: 'Awaiting Approval',
  awaiting_approval: 'Awaiting Approval',
  done: 'Done',
  completed: 'Done',
  skipped: 'Skipped',
  failed: 'Failed',
  error: 'Failed',
}

function statusIcon(status: string) {
  const s = (status || '').toLowerCase()
  if (['done', 'completed', 'success'].includes(s)) return <CheckCircle2 className="w-4 h-4 text-success" />
  if (['failed', 'error'].includes(s)) return <XCircle className="w-4 h-4 text-danger" />
  if (['pending_approval', 'awaiting_approval'].includes(s)) return <Clock className="w-4 h-4 text-warning" />
  if (['running', 'in_progress'].includes(s)) return <Loader2 className="w-4 h-4 text-accent animate-spin" />
  if (s === 'skipped') return <SkipForward className="w-4 h-4 text-muted" />
  return <AlertCircle className="w-4 h-4 text-muted" />
}

function statusBadge(status: string): string {
  const s = (status || '').toLowerCase()
  if (['done', 'completed', 'success'].includes(s)) return 'bg-success/10 text-success border-success/20'
  if (['failed', 'error'].includes(s)) return 'bg-danger/10 text-danger border-danger/20'
  if (['pending_approval', 'awaiting_approval'].includes(s)) return 'bg-warning/10 text-warning border-warning/20'
  if (['running', 'in_progress'].includes(s)) return 'bg-accent/10 text-accent border-accent/20'
  if (s === 'skipped') return 'bg-muted/10 text-muted border-border'
  return 'bg-panelHover text-muted border-border'
}

function relativeTime(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime()
  if (ms < 60000) return 'just now'
  const min = Math.floor(ms / 60000)
  if (min < 60) return min + 'm ago'
  const h = Math.floor(min / 60)
  if (h < 24) return h + 'h ago'
  return Math.floor(h / 24) + 'd ago'
}
export function Tasks() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [view, setView] = useState<'list' | 'kanban'>('list')
  const [statusTab, setStatusTab] = useState<string>('all')
  const [agentFilter, setAgentFilter] = useState<string>('all')
  const [search, setSearch] = useState('')
  const [detail, setDetail] = useState<Task | null>(null)
  const navigate = useNavigate()

  const token = () => localStorage.getItem('nexora_token')
  const authHeaders = () => ({ Authorization: 'Bearer ' + token() })

  async function fetchTasks() {
    try {
      const res = await fetch('/api/v1/orchestrator/tasks', { headers: authHeaders() })
      if (!res.ok) throw new Error('Failed to load tasks')
      const data = await res.json()
      setTasks(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    (async () => {
      await fetchTasks()
      setLoading(false)
    })()
  }, [])

  async function handleRefresh() {
    setRefreshing(true)
    await fetchTasks()
    setRefreshing(false)
  }

  const agents = useMemo(() => {
    const set = new Set(tasks.map((t) => t.agent_type))
    return ['all', ...Array.from(set).sort()]
  }, [tasks])

  const counts = useMemo(() => {
    const byStatus: Record<string, number> = {}
    for (const t of tasks) {
      const s = (t.status || '').toLowerCase()
      byStatus[s] = (byStatus[s] || 0) + 1
    }
    return {
      all: tasks.length,
      queued: (byStatus['queued'] || 0),
      running: (byStatus['running'] || 0) + (byStatus['in_progress'] || 0),
      pending: (byStatus['pending_approval'] || 0) + (byStatus['awaiting_approval'] || 0),
      done: (byStatus['done'] || 0) + (byStatus['completed'] || 0) + (byStatus['success'] || 0),
      skipped: byStatus['skipped'] || 0,
      failed: (byStatus['failed'] || 0) + (byStatus['error'] || 0),
    }
  }, [tasks])

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim()
    return tasks.filter((t) => {
      if (statusTab !== 'all') {
        const s = (t.status || '').toLowerCase()
        if (statusTab === 'pending') {
          if (!['pending_approval', 'awaiting_approval'].includes(s)) return false
        } else if (statusTab === 'done') {
          if (!['done', 'completed', 'success'].includes(s)) return false
        } else if (statusTab === 'running') {
          if (!['running', 'in_progress'].includes(s)) return false
        } else if (statusTab === 'failed') {
          if (!['failed', 'error'].includes(s)) return false
        } else if (statusTab === 'skipped') {
          if (s !== 'skipped') return false
        } else if (s !== statusTab) return false
      }
      if (agentFilter !== 'all' && t.agent_type !== agentFilter) return false
      if (q) {
        const hay = (t.description + ' ' + t.run_request + ' ' + (t.agent_type || '')).toLowerCase()
        if (!hay.includes(q)) return false
      }
      return true
    })
  }, [tasks, statusTab, agentFilter, search])

  const grouped = useMemo(() => {
    const g: Record<string, Task[]> = {}
    for (const s of STATUS_ORDER) g[s] = []
    for (const t of filtered) {
      const s = (t.status || '').toLowerCase()
      let key = 'queued'
      if (['done', 'completed', 'success'].includes(s)) key = 'done'
      else if (['failed', 'error'].includes(s)) key = 'failed'
      else if (['pending_approval', 'awaiting_approval'].includes(s)) key = 'pending_approval'
      else if (['running', 'in_progress'].includes(s)) key = 'running'
      else if (s === 'skipped') key = 'skipped'
      g[key].push(t)
    }
    return g
  }, [filtered])

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">Tasks</h1>
          <p className="text-sm text-muted">
            {loading ? 'Loading...' : counts.all + ' tasks across all runs'}
          </p>
        </div>
        <div className="flex gap-2">
          <div className="bg-background border border-border rounded-lg p-1 flex">
            <button onClick={() => setView('list')} className={'px-3 py-1 rounded text-xs flex items-center gap-1 ' + (view === 'list' ? 'bg-accent text-white' : 'text-muted')}>
              <List className="w-3 h-3" /> List
            </button>
            <button onClick={() => setView('kanban')} className={'px-3 py-1 rounded text-xs flex items-center gap-1 ' + (view === 'kanban' ? 'bg-accent text-white' : 'text-muted')}>
              <LayoutGrid className="w-3 h-3" /> Kanban
            </button>
          </div>
          <button onClick={handleRefresh} disabled={refreshing} className="bg-background border border-border text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-panelHover disabled:opacity-50 flex items-center gap-2">
            <RefreshCw className={'w-4 h-4 ' + (refreshing ? 'animate-spin' : '')} /> Refresh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-6 gap-4 mb-6">
        {[
          { label: 'Queued', value: counts.queued, icon: Clock, color: 'text-muted' },
          { label: 'Running', value: counts.running, icon: Loader2, color: 'text-accent' },
          { label: 'Awaiting Approval', value: counts.pending, icon: Clock, color: 'text-warning' },
          { label: 'Done', value: counts.done, icon: CheckCircle2, color: 'text-success' },
          { label: 'Skipped', value: counts.skipped, icon: SkipForward, color: 'text-muted' },
          { label: 'Failed', value: counts.failed, icon: XCircle, color: 'text-danger' },
        ].map((kpi) => (
          <div key={kpi.label} className="bg-background border border-border rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted mb-1">{kpi.label}</p>
              <p className="text-2xl font-bold text-white">{loading ? '...' : kpi.value}</p>
            </div>
            <kpi.icon className={'w-6 h-6 ' + kpi.color} />
          </div>
        ))}
      </div>
      <div className="bg-background border border-border rounded-xl p-4 mb-4 flex flex-wrap items-center gap-3">
        <div className="flex gap-1 flex-wrap">
          {([
            ['all', 'All (' + counts.all + ')'],
            ['queued', 'Queued (' + counts.queued + ')'],
            ['running', 'Running (' + counts.running + ')'],
            ['pending', 'Pending (' + counts.pending + ')'],
            ['done', 'Done (' + counts.done + ')'],
            ['skipped', 'Skipped (' + counts.skipped + ')'],
            ['failed', 'Failed (' + counts.failed + ')'],
          ] as const).map(([key, label]) => (
            <button key={key} onClick={() => setStatusTab(key)}
              className={'px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ' + (statusTab === key ? 'bg-accent text-white' : 'text-muted hover:bg-panelHover')}>
              {label}
            </button>
          ))}
        </div>
        <div className="flex-1" />
        <select value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)}
          className="bg-background border border-border rounded-lg px-3 py-1.5 text-sm text-white">
          {agents.map((a) => <option key={a} value={a}>{a === 'all' ? 'All agents' : a}</option>)}
        </select>
        <div className="relative">
          <Search className="w-4 h-4 text-muted absolute left-3 top-1/2 -translate-y-1/2" />
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search..."
            className="bg-background border border-border rounded-lg pl-9 pr-3 py-1.5 text-sm text-white w-56" />
        </div>
      </div>

      {loading ? (
        <div className="bg-background border border-border rounded-xl p-8 space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="animate-pulse flex gap-3">
              <div className="h-4 bg-border rounded w-24" />
              <div className="h-4 bg-border rounded w-32" />
              <div className="h-4 bg-border rounded flex-1" />
              <div className="h-4 bg-border rounded w-20" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-background border border-border rounded-xl p-12 text-center">
          <Calendar className="w-10 h-10 text-muted mx-auto mb-3 opacity-40" />
          <p className="text-sm text-white mb-1">{tasks.length === 0 ? 'No tasks yet' : 'No tasks match your filter'}</p>
          <p className="text-xs text-muted">{tasks.length === 0 ? 'Run an agent from the AI Assistant or Test Agent.' : 'Try changing filters.'}</p>
        </div>
      ) : view === 'list' ? (
        <div className="bg-background border border-border rounded-xl overflow-hidden">
          <table className="w-full text-left table-fixed">
            <colgroup>
              <col style={{ width: '100px' }} />
              <col style={{ width: '110px' }} />
              <col />
              <col style={{ width: '160px' }} />
              <col style={{ width: '140px' }} />
              <col style={{ width: '60px' }} />
            </colgroup>
            <thead>
              <tr className="bg-background border-b border-border text-xs text-muted uppercase tracking-wider">
                <th className="px-4 py-3 font-medium">Task</th>
                <th className="px-4 py-3 font-medium">Agent</th>
                <th className="px-4 py-3 font-medium">Description</th>
                <th className="px-4 py-3 font-medium">Run</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium text-right">Open</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((t) => (
                <tr key={t.task_id} className="hover:bg-backgroundHover cursor-pointer" onClick={() => setDetail(t)}>
                  <td className="px-4 py-3 text-xs font-mono text-white">#{t.raw_task_id}</td>
                  <td className="px-4 py-3">
                    <span className={'text-xs px-2 py-0.5 rounded border inline-flex items-center gap-1 ' + (AGENT_COLORS[t.agent_type] || 'bg-panelHover text-muted border-border')}>
                      <Bot className="w-3 h-3" /> {t.agent_type}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-300 truncate" title={t.description}>{t.description}</td>
                  <td className="px-4 py-3 text-xs text-muted truncate" title={t.run_request}>{t.run_request}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      {statusIcon(t.status)}
                      <span className={'text-xs px-2 py-0.5 rounded border ' + statusBadge(t.status)}>{STATUS_LABELS[t.status] || t.status}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button className="text-xs bg-background border border-border text-white px-2 py-1 rounded hover:bg-panelHover">
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {STATUS_ORDER.map((s) => (
            <div key={s} className="w-72 shrink-0 bg-background border border-border rounded-xl flex flex-col">
              <div className="px-4 py-3 border-b border-border bg-background flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">{STATUS_LABELS[s] || s}</h3>
                <span className="text-xs text-muted bg-background px-2 py-0.5 rounded">{(grouped[s] || []).length}</span>
              </div>
              <div className="p-2 space-y-2 max-h-[calc(100vh-500px)] overflow-y-auto">
                {(grouped[s] || []).length === 0 ? (
                  <div className="text-xs text-muted text-center py-6">No tasks</div>
                ) : grouped[s].map((t) => (
                  <button key={t.task_id} onClick={() => setDetail(t)} className="w-full text-left bg-background border border-border rounded-lg p-3 hover:border-accent/40 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-mono text-white">#{t.raw_task_id}</span>
                      <span className={'text-[10px] px-1.5 py-0.5 rounded border ' + (AGENT_COLORS[t.agent_type] || 'bg-panelHover text-muted border-border')}>{t.agent_type}</span>
                    </div>
                    <p className="text-xs text-gray-300 line-clamp-2 mb-1">{t.description}</p>
                    <p className="text-[10px] text-muted truncate">{t.run_request}</p>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      {detail && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="bg-background border border-border rounded-xl max-w-2xl w-full max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-border flex items-start justify-between shrink-0">
              <div>
                <h3 className="text-lg font-semibold text-white">Task #{detail.raw_task_id}</h3>
                <p className="text-xs text-muted mt-1">{detail.agent_type} - {relativeTime(detail.created_at)} - run #{detail.run_id.slice(0, 8)}</p>
              </div>
              <button onClick={() => setDetail(null)} className="text-muted hover:text-white p-1"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div>
                <p className="text-xs uppercase text-muted mb-1">Description</p>
                <p className="text-sm text-white">{detail.description}</p>
              </div>
              <div>
                <p className="text-xs uppercase text-muted mb-1">Run</p>
                <p className="text-sm text-white">{detail.run_request}</p>
                <button onClick={() => { setDetail(null); navigate('/executions'); }} className="mt-1 text-xs text-accent hover:underline flex items-center gap-1">
                  View run in Executions <ExternalLink className="w-3 h-3" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-background border border-border rounded-lg p-3">
                  <p className="text-[10px] text-muted uppercase mb-1">Status</p>
                  <span className={'text-xs px-2 py-0.5 rounded border ' + statusBadge(detail.status)}>{STATUS_LABELS[detail.status] || detail.status}</span>
                </div>
                <div className="bg-background border border-border rounded-lg p-3">
                  <p className="text-[10px] text-muted uppercase mb-1">Requires Approval</p>
                  <p className="text-sm text-white">{detail.requires_approval ? 'Yes' : 'No'}</p>
                </div>
              </div>
              {detail.approval_reason && (
                <div className="bg-warning/10 border border-warning/30 rounded-lg p-3">
                  <p className="text-xs uppercase text-warning mb-1">Approval Reason</p>
                  <p className="text-xs text-warning/90">{detail.approval_reason}</p>
                </div>
              )}
              {detail.approval_id && (
                <button onClick={() => { setDetail(null); navigate('/approvals'); }} className="text-xs text-accent hover:underline flex items-center gap-1">
                  Review approval #{detail.approval_id.slice(0, 8)} <ExternalLink className="w-3 h-3" />
                </button>
              )}
              {detail.result && (
                <div>
                  <p className="text-xs uppercase text-muted mb-2">Result</p>
                  <pre className="p-3 bg-background border border-border rounded-lg text-xs text-gray-300 overflow-x-auto max-h-64">
{JSON.stringify(detail.result, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}