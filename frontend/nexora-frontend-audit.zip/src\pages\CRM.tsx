import { useState, useEffect, useMemo } from 'react'
import { Search, Plus, Mail, Building2, Briefcase, ExternalLink, Loader2, AlertCircle, RefreshCw } from 'lucide-react'
import { Link } from 'react-router-dom'

interface HubSpotContact {
  id: string
  properties: {
    firstname?: string
    lastname?: string
    email?: string
    company?: string
    jobtitle?: string
    lifecyclestage?: string
    hs_lead_status?: string
    hubspot_owner_id?: string
    createdate?: string
    lastmodifieddate?: string
  }
  createdAt?: string
  updatedAt?: string
  url?: string
}

const STAGES: { key: string; label: string; matches: string[] }[] = [
  { key: 'new',         label: 'New Leads',       matches: ['lead', 'subscriber', ''] },
  { key: 'qualified',   label: 'Qualified',       matches: ['marketingqualifiedlead', 'mql'] },
  { key: 'contacted',   label: 'Contacted',       matches: ['salesqualifiedlead', 'sql'] },
  { key: 'demo',        label: 'Demo Scheduled',  matches: ['opportunity'] },
  { key: 'proposal',    label: 'Proposal',        matches: ['proposal'] },
  { key: 'negotiation', label: 'Negotiation',     matches: ['negotiation'] },
  { key: 'won',         label: 'Won',             matches: ['customer', 'evangelist'] },
  { key: 'lost',        label: 'Lost',            matches: ['other', 'unqualified'] },
]

function stageFor(stage: string | undefined): string {
  const s = (stage || '').toLowerCase()
  for (const def of STAGES) {
    if (def.matches.includes(s)) return def.key
  }
  return 'new'
}

function fullName(c: HubSpotContact): string {
  const f = c.properties.firstname || ''
  const l = c.properties.lastname || ''
  const name = (f + ' ' + l).trim()
  return name || c.properties.email || `Contact ${c.id.slice(-6)}`
}

function initials(name: string): string {
  return name.split(' ').filter(Boolean).slice(0, 2).map((n) => n[0]?.toUpperCase()).join('') || '?'
}

function timeAgo(iso: string | undefined): string {
  if (!iso) return ''
  const ms = Date.now() - new Date(iso).getTime()
  if (ms < 0) return 'just now'
  const min = Math.floor(ms / 60000)
  if (min < 1) return 'just now'
  if (min < 60) return `${min}m ago`
  const h = Math.floor(min / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  return `${d}d ago`
}

export function CRM() {
  const [contacts, setContacts] = useState<HubSpotContact[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')

  const token = () => localStorage.getItem('nexora_token')

  async function fetchContacts() {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/v1/integrations/hubspot/contacts', {
        headers: { Authorization: 'Bearer ' + token() },
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data.detail || `HTTP ${res.status}`)
      }
      const data = await res.json()
      setContacts(Array.isArray(data) ? data : [])
    } catch (err: any) {
      setError(err.message || 'Failed to load contacts')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchContacts() }, [])

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim()
    if (!q) return contacts
    return contacts.filter((c) => {
      const p = c.properties
      return (
        fullName(c).toLowerCase().includes(q) ||
        (p.company || '').toLowerCase().includes(q) ||
        (p.email || '').toLowerCase().includes(q) ||
        (p.jobtitle || '').toLowerCase().includes(q)
      )
    })
  }, [contacts, search])

  const grouped = useMemo(() => {
    const g: Record<string, HubSpotContact[]> = {}
    for (const def of STAGES) g[def.key] = []
    for (const c of filtered) {
      const stage = stageFor(c.properties.lifecyclestage)
      g[stage].push(c)
    }
    return g
  }, [filtered])

  const totalContacts = contacts.length

  return (
    <div className="p-8 h-[calc(100vh-64px)] flex flex-col bg-background">
      <div className="mb-6 flex items-start justify-between shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Sales Pipeline</h2>
          <p className="text-sm text-muted">
            {loading ? 'Loading...' : `${totalContacts} contact${totalContacts === 1 ? '' : 's'} synced from HubSpot`}
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={fetchContacts}
            disabled={loading}
            className="bg-background border border-border text-white px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-panelHover transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <Link
            to="/integrations"
            className="bg-background border border-border text-white px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-panelHover transition-colors"
          >
            <ExternalLink className="w-4 h-4" /> Manage HubSpot
          </Link>
        </div>
      </div>

      <div className="mb-4 shrink-0">
        <div className="relative max-w-md">
          <Search className="w-4 h-4 text-muted absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, company, email..."
            className="w-full bg-background border border-border rounded-lg pl-9 pr-3 py-2 text-sm text-white focus:outline-none focus:border-accent/50"
          />
        </div>
      </div>

      {error && (
        <div className="mb-4 bg-danger/10 border border-danger/30 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-danger shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-danger font-medium mb-1">Failed to load HubSpot contacts</p>
            <p className="text-xs text-danger/80 mb-3">{error}</p>
            <div className="flex gap-2">
              <button
                onClick={fetchContacts}
                className="text-xs bg-danger/20 text-danger px-3 py-1.5 rounded hover:bg-danger/30 transition-colors"
              >
                Retry
              </button>
              <Link
                to="/integrations"
                className="text-xs bg-background border border-border text-white px-3 py-1.5 rounded hover:bg-panelHover transition-colors"
              >
                Check Integrations
              </Link>
            </div>
          </div>
        </div>
      )}

      {loading && contacts.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-6 h-6 text-accent animate-spin mx-auto mb-2" />
            <p className="text-sm text-muted">Loading contacts from HubSpot...</p>
          </div>
        </div>
      ) : !loading && contacts.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md">
            <div className="w-16 h-16 bg-background border border-border rounded-xl flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-8 h-8 text-muted" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No contacts yet</h3>
            <p className="text-sm text-muted mb-4">
              HubSpot is connected but has no contacts, or the connection needs to be refreshed.
            </p>
            <div className="flex gap-2 justify-center">
              <Link
                to="/integrations"
                className="bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-accentHover"
              >
                Manage HubSpot
              </Link>
              <button
                onClick={fetchContacts}
                className="bg-background border border-border text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-panelHover"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-x-auto overflow-y-hidden">
          <div className="flex gap-4 h-full min-w-max">
            {STAGES.map((stage) => {
              const items = grouped[stage.key] || []
              return (
                <div
                  key={stage.key}
                  className="w-72 bg-background border border-border rounded-xl flex flex-col overflow-hidden"
                >
                  <div className="px-4 py-3 border-b border-border bg-background flex items-center justify-between shrink-0">
                    <h3 className="text-sm font-semibold text-white">{stage.label}</h3>
                    <span className="text-xs text-muted bg-background px-2 py-0.5 rounded">
                      {items.length}
                    </span>
                  </div>
                  <div className="flex-1 overflow-y-auto p-2 space-y-2">
                    {items.length === 0 ? (
                      <div className="text-xs text-muted text-center py-6">No contacts</div>
                    ) : items.map((c) => {
                      const name = fullName(c)
                      const p = c.properties
                      return (
                        <div
                          key={c.id}
                          className="bg-background border border-border rounded-lg p-3 hover:border-accent/40 transition-colors"
                        >
                          <div className="flex items-start gap-2 mb-2">
                            <div className="w-8 h-8 rounded-full bg-accent/20 text-accent flex items-center justify-center text-xs font-semibold shrink-0">
                              {initials(name)}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-medium text-white truncate">{name}</p>
                              {p.jobtitle && (
                                <p className="text-[11px] text-muted truncate flex items-center gap-1">
                                  <Briefcase className="w-3 h-3 shrink-0" /> {p.jobtitle}
                                </p>
                              )}
                            </div>
                          </div>
                          {p.company && (
                            <p className="text-xs text-gray-300 mb-1 flex items-center gap-1 truncate">
                              <Building2 className="w-3 h-3 text-muted shrink-0" /> {p.company}
                            </p>
                          )}
                          {p.email && (
                            <p className="text-xs text-muted mb-2 flex items-center gap-1 truncate">
                              <Mail className="w-3 h-3 shrink-0" /> {p.email}
                            </p>
                          )}
                          <div className="flex items-center justify-between pt-2 border-t border-border">
                            <span className="text-[10px] text-muted uppercase">
                              {p.lifecyclestage || 'lead'}
                            </span>
                            <span className="text-[10px] text-muted">
                              {timeAgo(p.lastmodifieddate || c.updatedAt)}
                            </span>
                          </div>
                          {c.url && (
                            <a
                              href={c.url}
                              target="_blank"
                              rel="noreferrer"
                              className="mt-2 text-[11px] text-accent hover:underline flex items-center gap-1"
                            >
                              Open in HubSpot <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}