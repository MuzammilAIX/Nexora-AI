import { useState, useEffect } from 'react'
import { Bot, Plus, Settings, Activity, CheckCircle2, Shield, Cpu, X, Play, Loader2, ExternalLink } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

const TEST_PROMPTS: Record<string, string> = {
  operations: 'show me low stock products',
  support:    'check my gmail for support emails about the system',
  lead:       'score my hubspot leads and create follow-up tasks',
  analytics:  'summarize last 7 days of business metrics',
  reporting:  'prepare a monthly sales report',
  email:      'draft and send an outbound email to a prospect',
  research:   'research the company Acme Corp',
  review:     'review recent agent outputs for quality issues',
}

export function Agents() {
  const [agents, setAgents] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<any | null>(null)
  const [testing, setTesting] = useState<string | null>(null)
  const [toast, setToast] = useState<any | null>(null)
  const navigate = useNavigate()

  const token = () => localStorage.getItem('nexora_token')

  useEffect(() => {
    async function fetchAgents() {
      try {
        const res = await fetch('/api/v1/orchestrator/agents', {
          headers: { Authorization: 'Bearer ' + token() },
        })
        if (res.ok) {
          const data = await res.json()
          setAgents(Array.isArray(data) ? data : [])
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchAgents()
  }, [])

  const handleTest = async (agent: any) => {
    setTesting(agent.id)
    setToast(null)
    try {
      const prompt = TEST_PROMPTS[agent.id] || ('run a quick test for the ' + agent.id + ' agent')
      const res = await fetch('/api/v1/orchestrator/run', {
        method: 'POST',
        headers: {
          Authorization: 'Bearer ' + token(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_request: prompt }),
      })
      const data = await res.json()
      if (!res.ok) {
        setToast({ kind: 'err', msg: data.detail || 'Test run failed' })
        return
      }
      const status = data.status || 'unknown'
      const runId = data.run_id || data.id || ''
      if (status === 'pending_approval' || status === 'paused') {
        setToast({ kind: 'pending', msg: 'Run paused for approval', runId })
      } else if (status === 'completed' || status === 'executed') {
        setToast({ kind: 'ok', msg: 'Run completed successfully', runId })
      } else {
        setToast({ kind: 'ok', msg: 'Run created (status: ' + status + ')', runId })
      }
    } catch (err: any) {
      setToast({ kind: 'err', msg: err.message || 'Network error' })
    } finally {
      setTesting(null)
    }
  }

  const closeToast = () => setToast(null)

  return (
    <div className="p-8 max-w-7xl mx-auto relative">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Agent Management</h2>
          <p className="text-sm text-muted">Configure, monitor, and manage your AI workforce.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-background border border-border text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-panelHover transition-colors">
            <Settings className="w-4 h-4" /> Global Settings
          </button>
          <button className="bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-accentHover transition-colors">
            <Plus className="w-4 h-4" /> Create Agent
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Agents', value: agents.length, icon: Bot, color: 'text-accent' },
          { label: 'Active Agents', value: agents.length, icon: CheckCircle2, color: 'text-success' },
          { label: 'Idle Agents', value: 0, icon: Activity, color: 'text-warning' },
          { label: 'Agents with Errors', value: 0, icon: Shield, color: 'text-danger' },
        ].map((kpi, i) => (
          <div key={i} className="bg-background border border-border rounded-xl p-5 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted mb-1">{kpi.label}</p>
              <p className="text-3xl font-bold text-white">{loading ? '...' : kpi.value}</p>
            </div>
            <div className={'w-10 h-10 rounded-lg bg-background flex items-center justify-center ' + kpi.color}>
              <kpi.icon className="w-5 h-5" />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-3 text-center text-muted py-12">Loading agents...</div>
        ) : agents.map((agent) => (
          <div key={agent.id} className="bg-background border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-colors group">
            <div className="p-5 border-b border-border flex justify-between items-start">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">{agent.name}</h3>
                  <p className="text-xs text-muted flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-success inline-block"></span> Active
                  </p>
                </div>
              </div>
              <button onClick={() => setSelected(agent)} className="text-muted hover:text-white p-1">
                <Settings className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5">
              <p className="text-sm text-gray-300 mb-4 h-10 line-clamp-2">{agent.description}</p>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-background rounded-lg p-2 border border-border">
                  <p className="text-[10px] text-muted uppercase mb-1">Model</p>
                  <p className="text-xs font-mono text-white flex items-center gap-1"><Cpu className="w-3 h-3" /> {agent.model}</p>
                </div>
                <div className="bg-background rounded-lg p-2 border border-border">
                  <p className="text-[10px] text-muted uppercase mb-1">Success</p>
                  <p className="text-xs font-mono text-success">{agent.success_rate}%</p>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setSelected(agent)}
                  className="flex-1 bg-accent/10 text-accent border border-accent/20 py-2 rounded-lg text-xs font-medium hover:bg-accent/20 transition-colors"
                >
                  View Details
                </button>
                <button
                  onClick={() => handleTest(agent)}
                  disabled={testing === agent.id}
                  className="flex-1 bg-background text-white border border-border py-2 rounded-lg text-xs font-medium hover:bg-backgroundHover transition-colors disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {testing === agent.id ? (
                    <><Loader2 className="w-3 h-3 animate-spin" /> Running...</>
                  ) : (
                    <><Play className="w-3 h-3" /> Test Agent</>
                  )}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="bg-background border border-border rounded-xl max-w-lg w-full p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">{selected.name}</h3>
                  <p className="text-xs text-muted font-mono">{selected.id}</p>
                </div>
              </div>
              <button onClick={() => setSelected(null)} className="text-muted hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-gray-300 mb-5">{selected.description}</p>
            <div className="grid grid-cols-2 gap-3 mb-5">
              {[
                ['Status', selected.status],
                ['Model', selected.model],
                ['Success Rate', selected.success_rate + '%'],
                ['Total Runs', selected.total_runs],
                ['Last Run', selected.last_run],
                ['Version', 'v1.0.0'],
              ].map(([k, v]) => (
                <div key={k} className="bg-background rounded-lg p-3 border border-border">
                  <p className="text-[10px] text-muted uppercase mb-1">{k}</p>
                  <p className="text-sm text-white">{v}</p>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => { setSelected(null); handleTest(selected) }}
                className="flex-1 bg-accent text-white py-2 rounded-lg text-sm font-medium hover:bg-accentHover flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4" /> Run Test
              </button>
              <button
                onClick={() => setSelected(null)}
                className="flex-1 bg-background text-white border border-border py-2 rounded-lg text-sm font-medium hover:bg-backgroundHover"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div
          className={
            'fixed bottom-6 right-6 z-50 border rounded-xl p-4 max-w-sm shadow-2xl bg-panel ' +
            (toast.kind === 'ok' ? 'border-success/50' : toast.kind === 'pending' ? 'border-warning/50' : 'border-danger/50')
          }
        >
          <div className="flex items-start gap-3">
            <div className="flex-1">
              <p className="text-sm text-white mb-1">{toast.msg}</p>
              {toast.runId && (
                <p className="text-xs text-muted font-mono">Run #{String(toast.runId).slice(0, 8)}</p>
              )}
              {toast.kind === 'pending' && (
                <button
                  onClick={() => { closeToast(); navigate('/mission-control') }}
                  className="mt-2 text-xs text-accent hover:underline flex items-center gap-1"
                >
                  Review in Mission Control <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
            <button onClick={closeToast} className="text-muted hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}