import { useState, useEffect, useCallback } from 'react'
import {
  ReactFlow, Background, Controls, MiniMap, useNodesState, useEdgesState, addEdge, Handle, Position
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import {
  Play, Settings, Zap, Bot, Database, Send, CheckCircle2, Activity, X, Loader2
} from 'lucide-react'

interface Run {
  id: string
  user_request: string
  status: string
  created_at: string
  completed_at?: string | null
}

function computeDuration(run: Run): string {
  if (!run.completed_at) return '-'
  const ms = new Date(run.completed_at).getTime() - new Date(run.created_at).getTime()
  if (ms < 0 || isNaN(ms)) return '-'
  if (ms < 1000) return ms + 'ms'
  if (ms < 60000) return (ms / 1000).toFixed(1) + 's'
  return Math.floor(ms / 60000) + 'm ' + Math.round((ms % 60000) / 1000) + 's'
}

function computeSuccessRate(runs: Run[]): number {
  if (runs.length === 0) return 0
  const completed = runs.filter((r) => r.status === 'completed').length
  return Math.round((completed / runs.length) * 100)
}

function computeAvgDuration(runs: Run[]): string {
  const completed = runs.filter((r) => r.completed_at && r.status === 'completed')
  if (completed.length === 0) return '-'
  const total = completed.reduce((sum, r) => {
    const ms = new Date(r.completed_at!).getTime() - new Date(r.created_at).getTime()
    return sum + (isNaN(ms) || ms < 0 ? 0 : ms)
  }, 0)
  const avgMs = total / completed.length
  if (avgMs < 1000) return Math.round(avgMs) + 'ms'
  if (avgMs < 60000) return (avgMs / 1000).toFixed(1) + 's'
  return Math.floor(avgMs / 60000) + 'm'
}

function statusLabel(status: string): string {
  const map: Record<string, string> = {
    completed: 'Completed',
    failed: 'Failed',
    pending_approval: 'Awaiting Approval',
    running: 'Running',
    queued: 'Queued',
  }
  return map[status] || status
}

function relativeTime(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime()
  if (ms < 60000) return 'just now'
  const min = Math.floor(ms / 60000)
  if (min < 60) return min + 'm ago'
  const h = Math.floor(min / 60)
  if (h < 24) return h + 'h ago'
  return Math.floor(h / 24) + 'd ago'
}

const CustomNode = ({ data }: any) => {
  const Icon = data.icon
  return (
    <div className="bg-background border-2 border-border hover:border-accent/50 rounded-xl shadow-xl min-w-[180px] overflow-hidden transition-colors">
      <div className="bg-backgroundHover px-3 py-2 border-b border-border flex items-center gap-2">
        <Icon className="w-4 h-4 text-accent" />
        <span className="text-xs font-semibold text-white truncate">{data.label}</span>
      </div>
      <div className="p-3">
        <p className="text-[11px] text-muted">{data.subLabel}</p>
      </div>
      <Handle type="target" position={Position.Left} className="!bg-accent !w-2 !h-2 !border-2 !border-panel" />
      <Handle type="source" position={Position.Right} className="!bg-accent !w-2 !h-2 !border-2 !border-panel" />
    </div>
  )
}

const nodeTypes = { custom: CustomNode }

const initialNodes = [
  { id: '1', type: 'custom', position: { x: 50, y: 150 }, data: { label: 'Webhook', subLabel: 'POST /lead', icon: Zap } },
  { id: '2', type: 'custom', position: { x: 300, y: 150 }, data: { label: 'Set Data', subLabel: 'Manual mapping', icon: Settings } },
  { id: '3', type: 'custom', position: { x: 550, y: 150 }, data: { label: 'OpenAI', subLabel: 'Message Model', icon: Bot } },
  { id: '4', type: 'custom', position: { x: 800, y: 50 }, data: { label: 'Slack', subLabel: 'Send Message', icon: Send } },
  { id: '5', type: 'custom', position: { x: 800, y: 250 }, data: { label: 'Postgres', subLabel: 'Insert Row', icon: Database } },
]

const initialEdges = [
  { id: 'e1-2', source: '1', target: '2', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 2 } },
  { id: 'e2-3', source: '2', target: '3', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 2 } },
  { id: 'e3-4', source: '3', target: '4', style: { stroke: '#8B5CF6', strokeWidth: 2 } },
  { id: 'e3-5', source: '3', target: '5', style: { stroke: '#8B5CF6', strokeWidth: 2 } },
]
export function Workflows() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)
  const [runs, setRuns] = useState<Run[]>([])
  const [loading, setLoading] = useState(true)
  const [showExecute, setShowExecute] = useState(false)
  const [executePrompt, setExecutePrompt] = useState('Score my HubSpot leads for B2B SaaS fit and create follow-up tasks for the best ones')
  const [executing, setExecuting] = useState(false)

  const token = () => localStorage.getItem('nexora_token')

  async function fetchRuns() {
    try {
      const res = await fetch('/api/v1/orchestrator/runs', {
        headers: { Authorization: 'Bearer ' + token() },
      })
      const data = await res.json()
      setRuns(Array.isArray(data) ? data : [])
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchRuns()
  }, [])

  const onConnect = useCallback((params: any) => setEdges((eds) => addEdge(params, eds)), [setEdges])

  async function handleExecute() {
    if (!executePrompt.trim()) return
    setExecuting(true)
    try {
      const res = await fetch('/api/v1/orchestrator/run', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + token(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_request: executePrompt }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Run failed')
      setShowExecute(false)
      await fetchRuns()
    } catch (e: any) {
      alert(e.message)
    } finally {
      setExecuting(false)
    }
  }
  return (
    <div className="flex flex-col bg-background" style={{ height: 'calc(100vh - 64px)' }}>
      <div className="px-6 py-4 border-b border-border flex justify-between items-center bg-background">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h2 className="text-xl font-bold text-white">Workflow Template: Lead Qualification</h2>
            <span className="px-2 py-0.5 rounded-full bg-success/10 text-success text-xs font-medium border border-success/20">Active</span>
          </div>
          <p className="text-xs text-muted font-mono flex items-center gap-2">
            ID: a1b2c3d4-e5f6-7890-abcd-1234567890ab
            <button className="hover:text-white"><Settings className="w-3 h-3" /></button>
          </p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-background border border-border text-white text-sm font-medium rounded-lg hover:bg-backgroundHover transition-colors">Edit Workflow</button>
          <button onClick={() => setShowExecute(true)} className="px-4 py-2 bg-accent text-white text-sm font-medium rounded-lg hover:bg-accentHover transition-colors flex items-center gap-2">
            <Play className="w-4 h-4" /> Execute Workflow
          </button>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        <div className="flex flex-col min-w-0 border-r border-border" style={{ flex: '1 1 0%', display: 'flex', flexDirection: 'column' }}>
          <div className="relative bg-background" style={{ flex: '1 1 0%', minHeight: '400px', width: '100%' }}>
            <ReactFlow
              style={{ width: '100%', height: '100%', position: 'absolute', inset: 0 }}
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              nodeTypes={nodeTypes}
              fitView
              proOptions={{ hideAttribution: true }}
            >
              <Background color="#1F2937" gap={16} size={2} />
              <Controls className="!bg-background !border-border !fill-white" />
              <MiniMap className="!bg-background !border-border" nodeColor="#8B5CF6" maskColor="rgba(0,0,0,0.7)" />
            </ReactFlow>
          </div>

          <div className="h-64 bg-background border-t border-border flex flex-col shrink-0">
            <div className="px-4 py-3 border-b border-border flex justify-between items-center bg-backgroundHover/30">
              <h3 className="text-sm font-semibold text-white">Execution History</h3>
              <button className="text-xs text-accent hover:text-accentHover font-medium">View All Executions</button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-xs text-muted bg-background sticky top-0 border-b border-border">
                  <tr>
                    <th className="px-4 py-2 font-medium">ID</th>
                    <th className="px-4 py-2 font-medium">Status</th>
                    <th className="px-4 py-2 font-medium">Started At</th>
                    <th className="px-4 py-2 font-medium">Request</th>
                    <th className="px-4 py-2 font-medium">Duration</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading ? (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted">Loading runs...</td></tr>
                  ) : runs.slice(0, 8).map((run) => (
                    <tr key={run.id} className="hover:bg-backgroundHover/50 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-muted">#{run.id.slice(0, 8)}</td>
                      <td className="px-4 py-3">
                        <span className={'inline-flex items-center gap-1.5 ' + (run.status === 'completed' ? 'text-success' : run.status === 'failed' ? 'text-danger' : 'text-warning')}>
                          {run.status === 'completed' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Activity className="w-3.5 h-3.5" />}
                          {statusLabel(run.status)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted text-xs">{new Date(run.created_at).toLocaleString()}</td>
                      <td className="px-4 py-3 text-white text-xs truncate max-w-xs" title={run.user_request}>{run.user_request || 'Untitled run'}</td>
                      <td className="px-4 py-3 text-muted text-xs font-mono">{computeDuration(run)}</td>
                    </tr>
                  ))}
                  {!loading && runs.length === 0 && (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted">No executions yet. Click "Execute Workflow" to create one.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div className="w-80 border-l border-border bg-background flex flex-col shrink-0 overflow-y-auto">
          <div className="p-4 border-b border-border">
            <h3 className="text-sm font-semibold text-white mb-3">System Overview</h3>
            <div className="space-y-3">
              <div>
                <p className="text-xs text-muted mb-1">Uptime</p>
                <p className="text-lg font-bold text-white">99.98%</p>
              </div>
              <div>
                <p className="text-xs text-muted mb-1">Error Rate</p>
                <p className="text-lg font-bold text-white">0%</p>
              </div>
              <p className="text-[10px] text-muted">Last 7 days</p>
            </div>
          </div>

          <div className="p-4 border-b border-border">
            <h3 className="text-sm font-semibold text-white mb-3">Workflow Stats</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted text-xs">Total Runs</span><span className="text-white text-xs font-mono">{runs.length}</span></div>
              <div className="flex justify-between"><span className="text-muted text-xs">Success Rate</span><span className="text-success text-xs font-mono">{computeSuccessRate(runs)}%</span></div>
              <div className="flex justify-between"><span className="text-muted text-xs">Avg. Duration</span><span className="text-white text-xs font-mono">{computeAvgDuration(runs)}</span></div>
              <div className="flex justify-between"><span className="text-muted text-xs">Failed</span><span className="text-danger text-xs font-mono">{runs.filter((r) => r.status === 'failed').length}</span></div>
              <div className="flex justify-between"><span className="text-muted text-xs">Awaiting Approval</span><span className="text-warning text-xs font-mono">{runs.filter((r) => r.status === 'pending_approval').length}</span></div>
            </div>
          </div>

          <div className="p-4">
            <h3 className="text-sm font-semibold text-white mb-3">Webhook Triggers</h3>
            <div className="space-y-2">
              {[
                { path: 'POST /lead', label: 'Lead Capture Webhook' },
                { path: 'POST /form-submission', label: 'Form Submission' },
                { path: 'POST /customer-update', label: 'Customer Update' },
              ].map((w) => (
                <div key={w.path} className="bg-background border border-border rounded-lg p-2">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] font-mono text-white">{w.path}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-success/10 text-success border border-success/20">Active</span>
                  </div>
                  <p className="text-[10px] text-muted">{w.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {showExecute && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => !executing && setShowExecute(false)}>
          <div className="bg-background border border-border rounded-xl max-w-lg w-full p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-semibold text-white">Execute Workflow</h3>
              <button onClick={() => !executing && setShowExecute(false)} className="text-muted hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-muted mb-4">Describe the workflow you want the orchestrator to run. This will create a new run.</p>
            <textarea
              value={executePrompt}
              onChange={(e) => setExecutePrompt(e.target.value)}
              disabled={executing}
              rows={4}
              className="w-full bg-background border border-border rounded-lg p-3 text-sm text-white focus:outline-none focus:border-accent/50 disabled:opacity-50"
            />
            <div className="flex gap-2 mt-4">
              <button
                onClick={handleExecute}
                disabled={executing || !executePrompt.trim()}
                className="flex-1 bg-accent text-white py-2 rounded-lg text-sm font-medium hover:bg-accentHover disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {executing ? <><Loader2 className="w-4 h-4 animate-spin" /> Executing...</> : <><Play className="w-4 h-4" /> Run</>}
              </button>
              <button
                onClick={() => setShowExecute(false)}
                disabled={executing}
                className="px-4 bg-background border border-border text-white py-2 rounded-lg text-sm font-medium hover:bg-panelHover disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
