import { useState, useEffect } from 'react'
import { User, Mail, Shield, LogOut, Building, Key, Save, Loader2, CheckCircle2, AlertCircle, Sun, Moon } from 'lucide-react'
import { useTheme, type Theme } from '../hooks/useTheme'

interface MeResponse {
  id: string
  email: string
  role: string
  tenant_id: string
  tenant_name?: string
}

export function Settings() {
  const { theme, setTheme } = useTheme()

  const [me, setMe] = useState<MeResponse | null>(null)
  const [loading, setLoading] = useState(true)

  const [newEmail, setNewEmail] = useState('')
  const [emailSaving, setEmailSaving] = useState(false)

  const [currentPw, setCurrentPw] = useState('')
  const [newPw, setNewPw] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [pwSaving, setPwSaving] = useState(false)

  const [orgName, setOrgName] = useState('')
  const [orgSaving, setOrgSaving] = useState(false)

  const [toast, setToast] = useState<{ kind: 'ok' | 'err'; msg: string } | null>(null)

  const token = () => localStorage.getItem('nexora_token')
  const authHeaders = () => ({ Authorization: 'Bearer ' + token(), 'Content-Type': 'application/json' })

  function flash(kind: 'ok' | 'err', msg: string) {
    setToast({ kind, msg })
    setTimeout(() => setToast(null), 3500)
  }

  async function fetchMe() {
    try {
      const res = await fetch('/api/v1/auth/me', { headers: authHeaders() })
      if (!res.ok) throw new Error('Failed to load profile')
      const data = await res.json()
      setMe(data)
      setNewEmail(data.email || '')
      setOrgName(data.tenant_name || '')
    } catch (err: any) {
      flash('err', err.message || 'Failed to load profile')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchMe() }, [])

  async function saveEmail(e: React.FormEvent) {
    e.preventDefault()
    if (!me || newEmail === me.email) { flash('err', 'Email unchanged'); return }
    setEmailSaving(true)
    try {
      const res = await fetch('/api/v1/auth/me', {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ email: newEmail }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Failed to update email')
      setMe(data)
      const stored = localStorage.getItem('nexora_user')
      if (stored) {
        try { const u = JSON.parse(stored); u.email = data.email; localStorage.setItem('nexora_user', JSON.stringify(u)) } catch {}
      }
      flash('ok', 'Email updated')
    } catch (err: any) {
      flash('err', err.message)
      setNewEmail(me?.email || '')
    } finally { setEmailSaving(false) }
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault()
    if (newPw !== confirmPw) { flash('err', 'New passwords do not match'); return }
    if (newPw.length < 8) { flash('err', 'Password must be at least 8 characters'); return }
    setPwSaving(true)
    try {
      const res = await fetch('/api/v1/auth/me', {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ current_password: currentPw, new_password: newPw }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Failed to change password')
      setCurrentPw(''); setNewPw(''); setConfirmPw('')
      flash('ok', 'Password changed')
    } catch (err: any) {
      flash('err', err.message)
    } finally { setPwSaving(false) }
  }

  async function saveOrg(e: React.FormEvent) {
    e.preventDefault()
    if (!me || orgName === (me.tenant_name || '')) { flash('err', 'Organization name unchanged'); return }
    setOrgSaving(true)
    try {
      const res = await fetch('/api/v1/auth/tenant', {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ name: orgName }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Failed to update organization')
      setMe({ ...me, tenant_name: data.name })
      flash('ok', 'Organization name updated')
    } catch (err: any) {
      flash('err', err.message)
    } finally { setOrgSaving(false) }
  }

  const handleLogout = () => {
    localStorage.removeItem('nexora_token')
    localStorage.removeItem('nexora_user')
    window.location.href = '/'
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      {/* ===== Theme ===== */}
      <section className="bg-background border border-border rounded-xl p-5 mb-5">
        <h2 className="text-sm font-semibold text-white mb-1">Appearance</h2>
        <p className="text-xs text-muted mb-4">Choose how Nexora looks to you.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {([
            { value: 'light' as Theme, label: 'Light', desc: 'Bright background', Icon: Sun },
            { value: 'dark'  as Theme, label: 'Dark',  desc: 'Dim, easy on eyes', Icon: Moon },
          ] as const).map(({ value, label, desc, Icon }) => {
            const active = theme === value
            return (
              <label
                key={value}
                className={
                  'flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ' +
                  (active
                    ? 'border-accent bg-panelHover'
                    : 'border-border hover:bg-panelHover')
                }
              >
                <input
                  type="radio"
                  name="nexora-theme"
                  value={value}
                  checked={active}
                  onChange={() => setTheme(value)}
                  className="mt-1 accent-[rgb(var(--color-accent))]"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-sm font-medium text-white">
                    <Icon className="w-4 h-4" /> {label}
                  </div>
                  <div className="text-xs text-muted mt-0.5">{desc}</div>
                </div>
              </label>
            )
          })}
        </div>
      </section>
      <h2 className="text-2xl font-bold text-white mb-1">Settings</h2>
      <p className="text-sm text-muted mb-8">Manage your profile and organization.</p>

      <div className="grid gap-6">
        {/* Profile Card */}
        <div className="bg-background border border-border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-accent" /> User Profile
          </h3>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center text-white text-2xl font-bold">
                {me?.email ? me.email[0].toUpperCase() : 'T'}
              </div>
              <div>
                <p className="text-white font-medium text-lg">{loading ? '...' : me?.email || 'Unknown'}</p>
                <p className="text-sm text-muted flex items-center gap-1">
                  <Shield className="w-3 h-3" /> {me?.role || 'admin'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6 border-t border-border pt-6">
              <div>
                <label className="text-xs text-muted mb-1 block">Email Address</label>
                <div className="flex items-center gap-2 bg-background border border-border rounded-lg px-3 py-2">
                  <Mail className="w-4 h-4 text-muted" />
                  <span className="text-sm text-white">{loading ? '...' : me?.email}</span>
                </div>
              </div>
              <div>
                <label className="text-xs text-muted mb-1 block">Tenant ID</label>
                <div className="flex items-center gap-2 bg-background border border-border rounded-lg px-3 py-2">
                  <Building className="w-4 h-4 text-muted" />
                  <span className="text-sm text-white font-mono truncate">{me?.tenant_id || '...'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Email Edit */}
        <form onSubmit={saveEmail} className="bg-background border border-border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Mail className="w-5 h-5 text-accent" /> Change Email
          </h3>
          <div className="flex gap-3">
            <input type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)}
              className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent/50"
              placeholder="new-email@example.com" />
            <button type="submit" disabled={emailSaving || loading}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accentHover disabled:opacity-50">
              {emailSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save
            </button>
          </div>
        </form>

        {/* Password Change */}
        <form onSubmit={savePassword} className="bg-background border border-border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Key className="w-5 h-5 text-accent" /> Change Password
          </h3>
          <div className="grid gap-3">
            <input type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} autoComplete="current-password"
              className="bg-background border border-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent/50"
              placeholder="Current password" />
            <input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password"
              className="bg-background border border-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent/50"
              placeholder="New password (min 8 chars)" />
            <input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} autoComplete="new-password"
              className="bg-background border border-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent/50"
              placeholder="Confirm new password" />
            <button type="submit" disabled={pwSaving}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accentHover disabled:opacity-50">
              {pwSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Update Password
            </button>
          </div>
        </form>

        {/* Organization */}
        <form onSubmit={saveOrg} className="bg-background border border-border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Building className="w-5 h-5 text-accent" /> Organization
          </h3>
          <div className="flex gap-3">
            <input type="text" value={orgName} onChange={(e) => setOrgName(e.target.value)}
              className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent/50"
              placeholder="Organization name" />
            <button type="submit" disabled={orgSaving || loading}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accentHover disabled:opacity-50">
              {orgSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save
            </button>
          </div>
          <p className="text-xs text-muted mt-2">Slug is immutable — it appears in URLs and cannot be changed.</p>
        </form>

        {/* Sign Out */}
        <div className="bg-background border border-border rounded-xl p-6 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Key className="w-5 h-5 text-accent" /> Session
            </h3>
            <p className="text-sm text-muted mt-1">You are currently signed in to the Command Center.</p>
          </div>
          <button onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-danger/10 text-danger border border-danger/20 rounded-lg hover:bg-danger/20 transition-colors">
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </div>

      {toast && (
        <div className={'fixed bottom-6 right-6 flex items-center gap-2 px-4 py-3 rounded-lg border shadow-lg ' +
          (toast.kind === 'ok' ? 'bg-success/10 text-success border-success/30' : 'bg-danger/10 text-danger border-danger/30')}>
          {toast.kind === 'ok' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span className="text-sm">{toast.msg}</span>
        </div>
      )}
    </div>
  )
}